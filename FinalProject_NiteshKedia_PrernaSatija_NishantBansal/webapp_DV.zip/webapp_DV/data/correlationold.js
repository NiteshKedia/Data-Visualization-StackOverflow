correlation = {
	"java": {
		"Q1": {
		//	"label":"java",
			"children":[
				{"label":"javascript", "value":0.54},
				{"label":"jsp", "value":0.23},
				{"label":"object-oriented", "value":0.10},
				{"label":"jsp", "value":0.23},
				{"label":"servelets", "value":0.12}
			]
		},
		"Q2": {
			//"label":"java",
			"value":1,
			"children":[
				{"label":"javascript", "value":0.54},
				{"label":"jsp", "value":0.18},
				{"label":"servelets", "value":0.20},
				{"label":"object-oriented", "value":0.10}
			]
		}
	},
	"javascript": {
		"Q1": {
		//	"label":"javascript",
			"value":1,
			"children":[
				{"label":"java", "value":0.54},
				{"label":"jsp", "value":0.12},
				{"label":"servelets", "value":0.04}
			]
		},
		"Q2": {
		//	"label":"javascript",
			"value":1,
			"children":[
				{"label":"java", "value":0.54},
				{"label":"jsp", "value":0.18},
				{"label":"servelets", "value":0.20},
				
			]
		}
	}
}